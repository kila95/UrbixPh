import React, { useState } from 'react';
import { ModuloControlSGSST } from './ModuloControlSGSST';
import { ModuloPermisosRemodelacion } from './ModuloPermisosRemodelacion';
import { ModuloPolizasGarantias } from './ModuloPolizasGarantias';
import { BandejaPreRegistrosAdmin } from './BandejaPreRegistrosAdmin';
import { ShieldCheck, Hammer, FileCheck2, Inbox } from 'lucide-react';

export function ContratistasModuleWrapper({ tenantId, onShowToast }: any) {
  const [subTab, setSubTab] = useState<'sgsst' | 'reformas' | 'polizas' | 'preregistros'>('sgsst');

  return (
    <div className="space-y-4">
      {/* Selector de submódulos */}
      <div className="flex flex-wrap items-center gap-2 bg-[#0b0f17] border border-slate-800/80 p-1.5 rounded-2xl w-fit">
        <button
          onClick={() => setSubTab('sgsst')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-mono font-bold transition cursor-pointer ${
            subTab === 'sgsst'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          1. Control SG-SST & ARL Garita
        </button>

        <button
          onClick={() => setSubTab('reformas')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-mono font-bold transition cursor-pointer ${
            subTab === 'reformas'
              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Hammer className="w-4 h-4" />
          2. Permisos de Remodelación & Depósitos
        </button>

        <button
          onClick={() => setSubTab('polizas')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-mono font-bold transition cursor-pointer ${
            subTab === 'polizas'
              ? 'bg-indigo-500/20 text-indigo-300 border border-indigo-500/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <FileCheck2 className="w-4 h-4" />
          3. Pólizas & Garantías Contractuales
        </button>

        <button
          onClick={() => setSubTab('preregistros')}
          className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-mono font-bold transition cursor-pointer ${
            subTab === 'preregistros'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Inbox className="w-4 h-4" />
          4. Bandeja Pre-registros Radicados
        </button>
      </div>

      {/* Renderizado dinámico */}
      {subTab === 'sgsst' && <ModuloControlSGSST tenantId={tenantId} onShowToast={onShowToast} />}
      {subTab === 'reformas' && <ModuloPermisosRemodelacion tenantId={tenantId} onShowToast={onShowToast} />}
      {subTab === 'polizas' && <ModuloPolizasGarantias tenantId={tenantId} onShowToast={onShowToast} />}
      {subTab === 'preregistros' && <BandejaPreRegistrosAdmin onShowToast={onShowToast} />}
    </div>
  );
}

export default ContratistasModuleWrapper;
