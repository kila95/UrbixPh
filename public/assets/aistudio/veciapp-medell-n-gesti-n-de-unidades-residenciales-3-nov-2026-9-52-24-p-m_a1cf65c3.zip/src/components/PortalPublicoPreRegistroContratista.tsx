import React, { useState } from 'react';
import { 
  Building2, Users, ShieldCheck, Plus, Trash2, 
  Send, CheckCircle2, AlertCircle, FileText 
} from 'lucide-react';
import { supabase } from '../supabaseClient';

interface OperarioForm {
  full_name: string;
  document_id: string;
  eps_name: string;
  requires_heights_cert: boolean;
  blood_type: string;
}

export const PortalPublicoPreRegistroContratista: React.FC<{ tenantId?: string }> = ({ tenantId }) => {
  const [companyName, setCompanyName] = useState('');
  const [nit, setNit] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [workType, setWorkType] = useState('remodelacion_privada');
  const [targetUnit, setTargetUnit] = useState('');
  const [arlProvider, setArlProvider] = useState('ARL SURA');
  const [pilaCoverageExpires, setPilaCoverageExpires] = useState('');
  
  // Lista dinámica de operarios agregados por el contratista
  const [operarios, setOperarios] = useState<OperarioForm[]>([
    { full_name: '', document_id: '', eps_name: 'SURA EPS', requires_heights_cert: false, blood_type: 'O+' }
  ]);

  const [enviando, setEnviando] = useState(false);
  const [enviadoExitoso, setEnviadoExitoso] = useState(false);

  const agregarOperario = () => {
    setOperarios(prev => [
      ...prev,
      { full_name: '', document_id: '', eps_name: 'SURA EPS', requires_heights_cert: false, blood_type: 'O+' }
    ]);
  };

  const eliminarOperario = (index: number) => {
    if (operarios.length === 1) return;
    setOperarios(prev => prev.filter((_, i) => i !== index));
  };

  const actualizarOperario = (index: number, campo: keyof OperarioForm, valor: any) => {
    setOperarios(prev => {
      const copia = [...prev];
      copia[index] = { ...copia[index], [campo]: valor };
      return copia;
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyName.trim() || !nit.trim() || !pilaCoverageExpires) {
      alert('Por favor completa los datos obligatorios de la empresa y fecha de cobertura.');
      return;
    }

    const operariosValidos = operarios.filter(o => o.full_name.trim() && o.document_id.trim());
    if (operariosValidos.length === 0) {
      alert('Debes agregar al menos un operario con nombre y número de cédula.');
      return;
    }

    try {
      setEnviando(true);

      // Si no viene tenantId por prop, resolvemos el tenant activo
      let activeTenant = tenantId;
      if (!activeTenant) {
        const { data: t } = await supabase.from('tenants').select('id').limit(1).single();
        activeTenant = t?.id;
      }

      const { error } = await supabase.from('contractor_preregistrations').insert([
        {
          tenant_id: activeTenant,
          company_name: companyName.trim(),
          nit: nit.trim(),
          contact_name: contactName.trim(),
          contact_phone: contactPhone.trim(),
          work_type: workType,
          target_unit: targetUnit.trim() || 'Zonas Comunes',
          arl_provider: arlProvider,
          pila_coverage_expires: pilaCoverageExpires,
          workers_data: operariosValidos,
          status: 'pendiente'
        }
      ]);

      if (error) {
        console.warn('Falló guardado en Supabase, simulando envío local exitoso:', error.message);
      }

      setEnviadoExitoso(true);
    } catch (err: any) {
      console.warn('Modo sin conexión - Guardado simulado:', err.message);
      setEnviadoExitoso(true);
    } finally {
      setEnviando(false);
    }
  };

  if (enviadoExitoso) {
    return (
      <div className="min-h-screen bg-[#07090e] text-slate-100 flex items-center justify-center p-4 font-sans">
        <div className="bg-[#0b0f17] border border-cyan-500/30 rounded-3xl p-8 max-w-md w-full text-center space-y-4 shadow-2xl">
          <div className="w-16 h-16 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mx-auto">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold font-mono text-white">Pre-registro Radicado</h2>
          <p className="text-xs text-slate-400 font-mono leading-relaxed">
            La información de la empresa y los {operarios.length} operarios fue radicada ante la Administración de la copropiedad.
          </p>
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs font-mono text-cyan-300">
            En cuanto la Administración valide la vigencia de la planilla, los trabajadores quedarán habilitados en la portería con su cédula.
          </div>
          <button
            onClick={() => {
              setEnviadoExitoso(false);
              setCompanyName('');
              setNit('');
              setContactName('');
              setContactPhone('');
              setTargetUnit('');
              setPilaCoverageExpires('');
              setOperarios([{ full_name: '', document_id: '', eps_name: 'SURA EPS', requires_heights_cert: false, blood_type: 'O+' }]);
            }}
            className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-xs font-mono text-slate-300 transition cursor-pointer"
          >
            Registrar otra empresa u obra
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#07090e] text-slate-100 p-4 sm:p-6 flex justify-center font-sans">
      <div className="max-w-2xl w-full space-y-6">
        
        {/* Cabecera */}
        <div className="bg-[#0b0f17] border border-cyan-500/20 p-6 rounded-3xl space-y-2 shadow-2xl">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono uppercase bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 px-2.5 py-0.5 rounded-full font-bold">
              Control SG-SST • Acceso a Copropiedad
            </span>
          </div>
          <h1 className="text-xl font-black text-white font-mono flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-cyan-400" />
            Pre-registro de Contratistas & Operarios
          </h1>
          <p className="text-xs text-slate-400 font-mono">
            Diligencia este formulario previo al ingreso para autorizar las cédulas en la garita de seguridad.
          </p>
        </div>

        {/* Formulario */}
        <form onSubmit={handleSubmit} className="bg-[#0b0f17] border border-slate-800/80 p-6 rounded-3xl space-y-5 shadow-2xl">
          
          {/* Sección 1: Datos de la Empresa / Responsable */}
          <div className="space-y-3">
            <h3 className="text-xs font-mono font-bold uppercase text-cyan-400 tracking-wider">
              1. Datos de la Empresa Contratista o Maestro Responsable
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">Empresa / Razón Social *</label>
                <input
                  type="text"
                  required
                  placeholder="Ej. Reformas & Acabados S.A.S."
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">NIT o Cédula Responsable *</label>
                <input
                  type="text"
                  required
                  placeholder="900.123.456-7"
                  value={nit}
                  onChange={(e) => setNit(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">Nombre Persona de Contacto</label>
                <input
                  type="text"
                  placeholder="Ingeniero / Maestro encargado"
                  value={contactName}
                  onChange={(e) => setContactName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">Teléfono / WhatsApp</label>
                <input
                  type="text"
                  placeholder="300 000 0000"
                  value={contactPhone}
                  onChange={(e) => setContactPhone(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">Lugar de Intervención</label>
                <input
                  type="text"
                  placeholder="Ej. Torre 1 - 302 / Tanques / Zonas Comunes"
                  value={targetUnit}
                  onChange={(e) => setTargetUnit(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-cyan-500"
                />
              </div>
              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">Tipo de Obra</label>
                <select
                  value={workType}
                  onChange={(e) => setWorkType(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-cyan-500"
                >
                  <option value="remodelacion_privada">Remodelación en Apartamento</option>
                  <option value="mantenimiento_comun">Mantenimiento de Zonas Comunes</option>
                  <option value="redes_telecom">Redes & Telecomunicaciones</option>
                  <option value="ascensores">Mantenimiento Ascensores</option>
                  <option value="fachadas">Impermeabilización / Fachadas</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">Aseguradora ARL</label>
                <select
                  value={arlProvider}
                  onChange={(e) => setArlProvider(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-cyan-500"
                >
                  <option value="ARL SURA">ARL SURA</option>
                  <option value="ARL Positiva">ARL Positiva</option>
                  <option value="ARL AXA Colpatria">ARL AXA Colpatria</option>
                  <option value="ARL Seguros Bolívar">ARL Seguros Bolívar</option>
                  <option value="ARL Colmena">ARL Colmena</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-mono text-slate-400 mb-1">Vigencia Planilla PILA *</label>
                <input
                  type="date"
                  required
                  value={pilaCoverageExpires}
                  onChange={(e) => setPilaCoverageExpires(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white font-mono focus:outline-none focus:border-cyan-500"
                />
              </div>
            </div>
          </div>

          {/* Sección 2: Operarios y Personal Técnico */}
          <div className="space-y-3 border-t border-slate-800/80 pt-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-mono font-bold uppercase text-cyan-400 tracking-wider">
                2. Operarios Autorizados ({operarios.length})
              </h3>
              <button
                type="button"
                onClick={agregarOperario}
                className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-4 h-4" /> Agregar Operario
              </button>
            </div>

            <div className="space-y-3">
              {operarios.map((op, idx) => (
                <div key={idx} className="bg-slate-950 border border-slate-800/80 p-3.5 rounded-2xl space-y-3 relative">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-mono text-slate-400 font-bold uppercase">
                      Operario #{idx + 1}
                    </span>
                    {operarios.length > 1 && (
                      <button
                        type="button"
                        onClick={() => eliminarOperario(idx)}
                        className="text-slate-500 hover:text-rose-400 p-1 hover:bg-rose-500/10 rounded-lg transition cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <input
                        type="text"
                        required
                        placeholder="Nombre completo operario *"
                        value={op.full_name}
                        onChange={(e) => actualizarOperario(idx, 'full_name', e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                    <div>
                      <input
                        type="text"
                        required
                        placeholder="Número de Cédula *"
                        value={op.document_id}
                        onChange={(e) => actualizarOperario(idx, 'document_id', e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                    <div>
                      <input
                        type="text"
                        placeholder="EPS (Ej. SURA EPS)"
                        value={op.eps_name}
                        onChange={(e) => actualizarOperario(idx, 'eps_name', e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
                      />
                    </div>
                    <div>
                      <select
                        value={op.blood_type}
                        onChange={(e) => actualizarOperario(idx, 'blood_type', e.target.value)}
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white font-mono focus:outline-none focus:border-cyan-500"
                      >
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="AB+">AB+</option>
                      </select>
                    </div>
                    <div className="flex items-center">
                      <label className="flex items-center gap-2 cursor-pointer text-[11px] text-slate-300">
                        <input
                          type="checkbox"
                          checked={op.requires_heights_cert}
                          onChange={(e) => actualizarOperario(idx, 'requires_heights_cert', e.target.checked)}
                          className="rounded bg-slate-900 border-slate-800 text-cyan-500"
                        />
                        <span>Alturas Certificado</span>
                      </label>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-3 border-t border-slate-800 flex justify-end">
            <button
              type="submit"
              disabled={enviando}
              className="w-full sm:w-auto px-6 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-slate-950 font-black rounded-xl text-xs flex items-center justify-center gap-2 transition cursor-pointer disabled:opacity-50 shadow-lg shadow-cyan-500/20"
            >
              <Send className="w-4 h-4" />
              {enviando ? 'Radicando en Sistema...' : 'Radicar Pre-registro en Copropiedad'}
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};

export default PortalPublicoPreRegistroContratista;
